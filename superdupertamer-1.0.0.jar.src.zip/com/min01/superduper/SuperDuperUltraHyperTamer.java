/*    */ package com.min01.superduper;
/*    */ 
/*    */ import com.min01.superduper.config.SuperDuperConfig;
/*    */ import com.min01.superduper.item.SuperDuperItems;
/*    */ import net.minecraftforge.eventbus.api.IEventBus;
/*    */ import net.minecraftforge.fml.ModLoadingContext;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.config.IConfigSpec;
/*    */ import net.minecraftforge.fml.config.ModConfig;
/*    */ import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
/*    */ 
/*    */ 
/*    */ @Mod("superdupertamer")
/*    */ public class SuperDuperUltraHyperTamer
/*    */ {
/*    */   public static final String MODID = "superdupertamer";
/*    */   
/*    */   public SuperDuperUltraHyperTamer() {
/* 19 */     IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
/* 20 */     ModLoadingContext ctx = ModLoadingContext.get();
/* 21 */     SuperDuperItems.ITEMS.register(bus);
/*    */     
/* 23 */     ctx.registerConfig(ModConfig.Type.COMMON, (IConfigSpec)SuperDuperConfig.CONFIG_SPEC, "super-duper-tamer.toml");
/*    */   }
/*    */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superduper\SuperDuperUltraHyperTamer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */