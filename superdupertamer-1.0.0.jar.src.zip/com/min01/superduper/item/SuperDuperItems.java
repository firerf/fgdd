/*    */ package com.min01.superduper.item;
/*    */ 
/*    */ import net.minecraft.world.item.Item;
/*    */ import net.minecraftforge.registries.DeferredRegister;
/*    */ import net.minecraftforge.registries.ForgeRegistries;
/*    */ import net.minecraftforge.registries.RegistryObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SuperDuperItems
/*    */ {
/* 12 */   public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, "superdupertamer");
/*    */   
/* 14 */   public static final RegistryObject<Item> SUPER_DUPER_ULTRA_HYPER_LEAD = ITEMS.register("super_duper_ultra_hyper_lead", () -> new SuperDuperUltraHyperLeadItem());
/*    */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superduper\item\SuperDuperItems.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */