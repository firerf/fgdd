/*    */ package com.min01.superduper.item;
/*    */ 
/*    */ import com.min01.superduper.config.SuperDuperConfig;
/*    */ import com.min01.superduper.util.SuperDuperUtil;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.world.InteractionHand;
/*    */ import net.minecraft.world.InteractionResult;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.entity.player.Player;
/*    */ import net.minecraft.world.item.Item;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SuperDuperUltraHyperLeadItem
/*    */   extends Item
/*    */ {
/*    */   public SuperDuperUltraHyperLeadItem() {
/* 19 */     super((new Item.Properties()).m_41487_(1));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public InteractionResult m_6880_(ItemStack p_41398_, Player p_41399_, LivingEntity p_41400_, InteractionHand p_41401_) {
/* 25 */     if (!SuperDuperUtil.isTame(p_41400_)) {
/*    */       
/* 27 */       boolean flag = ((Boolean)SuperDuperConfig.forceTame.get()).booleanValue() ? true : (!(p_41400_ instanceof net.minecraft.world.entity.TamableAnimal));
/* 28 */       if (flag) {
/*    */         
/* 30 */         SuperDuperUtil.tame(p_41400_, (LivingEntity)p_41399_);
/* 31 */         return InteractionResult.SUCCESS;
/*    */       } 
/*    */ 
/*    */       
/* 35 */       p_41399_.m_5661_((Component)Component.m_237115_("entity.superduper.already_tameable"), true);
/*    */     } 
/*    */     
/* 38 */     return super.m_6880_(p_41398_, p_41399_, p_41400_, p_41401_);
/*    */   }
/*    */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superduper\item\SuperDuperUltraHyperLeadItem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */