/*     */ package com.min01.superduper.mixin;
/*     */ 
/*     */ import com.min01.superduper.util.SuperDuperUtil;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.Mob;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.phys.Vec3;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.ModifyVariable;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({LivingEntity.class})
/*     */ public abstract class MixinLivingEntity
/*     */   extends MixinEntity
/*     */ {
/*     */   @Inject(at = {@At("HEAD")}, method = {"addAdditionalSaveData"})
/*     */   private void addAdditionalSaveData(CompoundTag tag, CallbackInfo ci) {
/*  24 */     LivingEntity living = LivingEntity.class.cast(this);
/*  25 */     if (SuperDuperUtil.isTame(living))
/*     */     {
/*  27 */       tag.m_128362_("OwnerUUID", SuperDuperUtil.getOwner(living).m_20148_());
/*     */     }
/*  29 */     if (SuperDuperUtil.getLastHurtByMob(living) != null)
/*     */     {
/*  31 */       tag.m_128362_("LastHurtByMobUUID", SuperDuperUtil.getLastHurtByMob(living).m_20148_());
/*     */     }
/*  33 */     if (SuperDuperUtil.getLastHurtMob(living) != null)
/*     */     {
/*  35 */       tag.m_128362_("LastHurtMobUUID", SuperDuperUtil.getLastHurtMob(living).m_20148_());
/*     */     }
/*  37 */     tag.m_128405_("Command", SuperDuperUtil.getCommand(living));
/*     */   }
/*     */ 
/*     */   
/*     */   @Inject(at = {@At("HEAD")}, method = {"readAdditionalSaveData"})
/*     */   private void readAdditionalSaveData(CompoundTag tag, CallbackInfo ci) {
/*  43 */     LivingEntity living = LivingEntity.class.cast(this);
/*  44 */     if (tag.m_128441_("OwnerUUID")) {
/*     */       
/*  46 */       Entity entity = SuperDuperUtil.getEntityByUUID(living.f_19853_, tag.m_128342_("OwnerUUID"));
/*  47 */       if (entity instanceof LivingEntity) { LivingEntity owner = (LivingEntity)entity;
/*     */         
/*  49 */         SuperDuperUtil.setOwner(living, owner); }
/*     */     
/*     */     } 
/*  52 */     if (tag.m_128441_("LastHurtByMobUUID")) {
/*     */       
/*  54 */       Entity entity = SuperDuperUtil.getEntityByUUID(living.f_19853_, tag.m_128342_("LastHurtByMobUUID"));
/*  55 */       if (entity instanceof LivingEntity) { LivingEntity lastHurtByMob = (LivingEntity)entity;
/*     */         
/*  57 */         SuperDuperUtil.setLastHurtByMob(living, lastHurtByMob); }
/*     */     
/*     */     } 
/*  60 */     if (tag.m_128441_("LastHurtMobUUID")) {
/*     */       
/*  62 */       Entity entity = SuperDuperUtil.getEntityByUUID(living.f_19853_, tag.m_128342_("LastHurtMobUUID"));
/*  63 */       if (entity instanceof LivingEntity) { LivingEntity lastHurtMob = (LivingEntity)entity;
/*     */         
/*  65 */         SuperDuperUtil.setLastHurtMob(living, lastHurtMob); }
/*     */     
/*     */     } 
/*  68 */     if (tag.m_128441_("Command"))
/*     */     {
/*  70 */       SuperDuperUtil.setCommand(living, tag.m_128451_("Command"));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @ModifyVariable(at = @At("HEAD"), method = {"travel"})
/*     */   private Vec3 travel(Vec3 vec3) {
/*  77 */     LivingEntity living = LivingEntity.class.cast(this);
/*  78 */     if (SuperDuperUtil.isTame(living)) {
/*     */       
/*  80 */       if (living.m_146895_() != null)
/*     */       {
/*  82 */         if (SuperDuperUtil.getOwner(living) == living.m_146895_()) {
/*     */           
/*  84 */           Entity entity = living.m_146895_();
/*  85 */           if (entity instanceof Player) { Player player = (Player)entity;
/*     */             
/*  87 */             Vec3 travelVector = new Vec3(player.f_20900_, player.f_20901_, player.f_20902_);
/*  88 */             if (player.f_20902_ != 0.0F || player.f_20900_ != 0.0F) {
/*     */               
/*  90 */               m_19915_(player.m_146908_(), player.m_146909_() * 0.25F);
/*  91 */               living.m_5616_(player.m_6080_());
/*  92 */               ((Mob)living).m_6710_(null);
/*     */             } 
/*  94 */             return travelVector; }
/*     */         
/*     */         } 
/*     */       }
/*  98 */       if (SuperDuperUtil.isSit(living))
/*     */       {
/* 100 */         return Vec3.f_82478_;
/*     */       }
/*     */     } 
/* 103 */     return vec3;
/*     */   }
/*     */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superduper\mixin\MixinLivingEntity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */