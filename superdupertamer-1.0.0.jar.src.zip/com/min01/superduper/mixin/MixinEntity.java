/*    */ package com.min01.superduper.mixin;
/*    */ 
/*    */ import com.min01.superduper.util.SuperDuperUtil;
/*    */ import net.minecraft.world.entity.Entity;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({Entity.class})
/*    */ public class MixinEntity
/*    */ {
/*    */   @Inject(at = {@At("HEAD")}, method = {"isAlliedTo"}, cancellable = true)
/*    */   protected void isAlliedTo(Entity target, CallbackInfoReturnable<Boolean> cir) {
/* 20 */     Entity entity = Entity.class.cast(this);
/* 21 */     if (entity instanceof LivingEntity) { LivingEntity living = (LivingEntity)entity;
/*    */       
/* 23 */       if (SuperDuperUtil.isTame(living) && target instanceof LivingEntity) { LivingEntity livingTarget = (LivingEntity)target;
/*    */         
/* 25 */         LivingEntity owner = SuperDuperUtil.getOwner(living);
/* 26 */         if (SuperDuperUtil.isAllay(owner, living, livingTarget))
/*    */         {
/* 28 */           cir.setReturnValue(Boolean.valueOf(true));
/*    */         } }
/*    */        }
/*    */   
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(at = {@At("HEAD")}, method = {"getPassengersRidingOffset"}, cancellable = true)
/*    */   protected void getPassengersRidingOffset(CallbackInfoReturnable<Double> cir) {
/* 37 */     Entity entity = Entity.class.cast(this);
/* 38 */     if (entity instanceof LivingEntity) { LivingEntity living = (LivingEntity)entity;
/*    */       
/* 40 */       if (SuperDuperUtil.isTame(living))
/*    */       {
/* 42 */         if (living.m_146895_() != null)
/*    */         {
/* 44 */           if (SuperDuperUtil.getOwner(living) == living.m_146895_())
/*    */           {
/* 46 */             cir.setReturnValue(Double.valueOf(SuperDuperUtil.parseRideOffset(living)));
/*    */           }
/*    */         }
/*    */       } }
/*    */   
/*    */   }
/*    */   
/*    */   @Shadow
/*    */   protected void m_19915_(float p_19916_, float p_19917_) {}
/*    */   
/*    */   @Shadow
/*    */   protected void m_146872_() {}
/*    */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superduper\mixin\MixinEntity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */