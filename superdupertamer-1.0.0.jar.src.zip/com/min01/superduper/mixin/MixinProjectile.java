/*    */ package com.min01.superduper.mixin;
/*    */ 
/*    */ import com.min01.superduper.util.SuperDuperUtil;
/*    */ import net.minecraft.world.entity.Entity;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.entity.projectile.Projectile;
/*    */ import net.minecraft.world.phys.EntityHitResult;
/*    */ import net.minecraft.world.phys.HitResult;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({Projectile.class})
/*    */ public class MixinProjectile
/*    */ {
/*    */   @Inject(at = {@At("HEAD")}, method = {"onHit"}, cancellable = true)
/*    */   private void onHit(HitResult hitResult, CallbackInfo ci) {
/* 22 */     Projectile projectile = Projectile.class.cast(this);
/* 23 */     if (projectile.m_19749_() != null) {
/*    */       
/* 25 */       Entity owner = projectile.m_19749_();
/* 26 */       if (owner instanceof LivingEntity) { LivingEntity living = (LivingEntity)owner;
/*    */         
/* 28 */         if (hitResult instanceof EntityHitResult) { EntityHitResult entityHit = (EntityHitResult)hitResult;
/*    */           
/* 30 */           Entity entity = entityHit.m_82443_();
/* 31 */           if (entity instanceof LivingEntity) { LivingEntity livingHit = (LivingEntity)entity;
/*    */             
/* 33 */             if (SuperDuperUtil.isTame(living))
/*    */             {
/* 35 */               if (SuperDuperUtil.isAllay(SuperDuperUtil.getOwner(living), living, livingHit))
/*    */               {
/* 37 */                 ci.cancel();
/*    */               }
/*    */             } }
/*    */            }
/*    */          }
/*    */     
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superduper\mixin\MixinProjectile.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */