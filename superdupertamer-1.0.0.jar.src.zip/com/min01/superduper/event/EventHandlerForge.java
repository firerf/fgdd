/*     */ package com.min01.superduper.event;
/*     */ 
/*     */ import com.min01.superduper.ai.goal.SuperDuperFollowOwnerGoal;
/*     */ import com.min01.superduper.ai.goal.SuperDuperOwnerHurtByTargetGoal;
/*     */ import com.min01.superduper.ai.goal.SuperDuperOwnerHurtTargetGoal;
/*     */ import com.min01.superduper.command.TameCommand;
/*     */ import com.min01.superduper.util.SuperDuperUtil;
/*     */ import net.minecraft.core.particles.ParticleOptions;
/*     */ import net.minecraft.core.particles.ParticleTypes;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.world.InteractionResult;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.Mob;
/*     */ import net.minecraft.world.entity.TamableAnimal;
/*     */ import net.minecraft.world.entity.ai.goal.Goal;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.item.Item;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.level.GameRules;
/*     */ import net.minecraftforge.event.RegisterCommandsEvent;
/*     */ import net.minecraftforge.event.entity.EntityJoinLevelEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingAttackEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*     */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.Mod;
/*     */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ @EventBusSubscriber(modid = "superdupertamer", bus = Mod.EventBusSubscriber.Bus.FORGE)
/*     */ public class EventHandlerForge
/*     */ {
/*     */   @SubscribeEvent
/*     */   public static void onRegisterCommands(RegisterCommandsEvent event) {
/*  39 */     TameCommand.register(event.getDispatcher());
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public static void onLivingTick(LivingEvent.LivingTickEvent event) {
/*  45 */     LivingEntity living = event.getEntity();
/*  46 */     if (SuperDuperUtil.isTame(living))
/*     */     {
/*  48 */       if (living instanceof Mob) { Mob mob = (Mob)living;
/*     */         
/*  50 */         LivingEntity owner = SuperDuperUtil.getOwner((LivingEntity)mob);
/*  51 */         if (!mob.f_19853_.f_46443_)
/*     */         {
/*  53 */           if (mob.m_5448_() == null) {
/*     */             
/*  55 */             if (owner.m_21188_() != null)
/*     */             {
/*  57 */               if (!SuperDuperUtil.isAllay(owner, (LivingEntity)mob, owner.m_21188_()))
/*     */               {
/*  59 */                 if (SuperDuperUtil.isWandering((LivingEntity)mob) || SuperDuperUtil.isInAttackRange((LivingEntity)mob, (Entity)owner.m_21188_())) {
/*     */                   
/*  61 */                   mob.m_6710_(owner.m_21188_());
/*  62 */                   SuperDuperUtil.setLastHurtByMob((LivingEntity)mob, owner.m_21188_());
/*     */                 } 
/*     */               }
/*     */             }
/*  66 */             if (owner.m_21214_() != null)
/*     */             {
/*  68 */               if (!SuperDuperUtil.isAllay(owner, (LivingEntity)mob, owner.m_21214_()))
/*     */               {
/*  70 */                 if (SuperDuperUtil.isWandering((LivingEntity)mob) || SuperDuperUtil.isInAttackRange((LivingEntity)mob, (Entity)owner.m_21214_())) {
/*     */                   
/*  72 */                   mob.m_6710_(owner.m_21214_());
/*  73 */                   SuperDuperUtil.setLastHurtMob((LivingEntity)mob, owner.m_21214_());
/*     */                 } 
/*     */               }
/*     */             }
/*     */           } 
/*     */         } }
/*     */     
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public static void onLivingChangeTarget(LivingChangeTargetEvent event) {
/*  86 */     LivingEntity living = event.getEntity();
/*  87 */     LivingEntity target = event.getOriginalTarget();
/*  88 */     if (target != null) {
/*     */       
/*  90 */       if (SuperDuperUtil.isTame(living))
/*     */       {
/*  92 */         if (living instanceof Mob) { Mob mob = (Mob)living;
/*     */           
/*  94 */           LivingEntity owner = SuperDuperUtil.getOwner((LivingEntity)mob);
/*  95 */           if (SuperDuperUtil.getLastHurtByMob((LivingEntity)mob) != null) {
/*     */             
/*  97 */             boolean flag = (SuperDuperUtil.isFollow((LivingEntity)mob) && !SuperDuperUtil.isInAttackRange((LivingEntity)mob, (Entity)target));
/*  98 */             if (target != SuperDuperUtil.getLastHurtByMob((LivingEntity)mob) || flag)
/*     */             {
/* 100 */               event.setCanceled(true);
/*     */             }
/*     */           } 
/*     */           
/* 104 */           if (SuperDuperUtil.isAllay(owner, (LivingEntity)mob, target) || SuperDuperUtil.getLastHurtByMob((LivingEntity)mob) == null)
/*     */           {
/* 106 */             event.setCanceled(true);
/*     */           }
/*     */           
/* 109 */           if (SuperDuperUtil.getLastHurtMob((LivingEntity)mob) != null) {
/*     */             
/* 111 */             boolean flag = (SuperDuperUtil.isFollow((LivingEntity)mob) && !SuperDuperUtil.isInAttackRange((LivingEntity)mob, (Entity)target));
/* 112 */             if (target != SuperDuperUtil.getLastHurtMob((LivingEntity)mob) || flag)
/*     */             {
/* 114 */               event.setCanceled(true);
/*     */             }
/*     */           } 
/*     */           
/* 118 */           if (SuperDuperUtil.isAllay(owner, (LivingEntity)mob, target) || SuperDuperUtil.getLastHurtMob((LivingEntity)mob) == null)
/*     */           {
/* 120 */             event.setCanceled(true);
/*     */           } }
/*     */       
/*     */       }
/* 124 */       if (living instanceof TamableAnimal) { TamableAnimal animal = (TamableAnimal)living;
/*     */         
/* 126 */         if (animal.m_269323_() != null)
/*     */         {
/* 128 */           if (SuperDuperUtil.isAllay(animal.m_269323_(), (LivingEntity)animal, target))
/*     */           {
/* 130 */             event.setCanceled(true);
/*     */           }
/*     */         } }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
/* 140 */     Entity entity = event.getEntity();
/* 141 */     if (entity instanceof LivingEntity) { LivingEntity living = (LivingEntity)entity;
/*     */       
/* 143 */       if (living instanceof Mob) { Mob mob = (Mob)living;
/*     */         
/* 145 */         if (!mob.f_19853_.f_46443_) {
/*     */           
/* 147 */           mob.f_21345_.m_25352_(2, (Goal)new SuperDuperFollowOwnerGoal(mob, SuperDuperUtil.parseMovementSpeed((LivingEntity)mob), 4.0F, 2.0F, true));
/* 148 */           mob.f_21346_.m_25352_(1, (Goal)new SuperDuperOwnerHurtByTargetGoal(mob));
/* 149 */           mob.f_21346_.m_25352_(2, (Goal)new SuperDuperOwnerHurtTargetGoal(mob));
/*     */         }  }
/*     */        }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
/* 158 */     Player player = event.getEntity();
/* 159 */     ItemStack stack = event.getItemStack();
/* 160 */     Entity entity = event.getTarget();
/* 161 */     if (entity instanceof LivingEntity) { LivingEntity living = (LivingEntity)entity; if (!SuperDuperUtil.isBlacklisted(living))
/*     */       {
/* 163 */         if (!SuperDuperUtil.isTame(living)) {
/*     */           
/* 165 */           Item item = SuperDuperUtil.parseItemForTaming(living);
/* 166 */           if (item != null)
/*     */           {
/* 168 */             if (stack.m_150930_(item))
/*     */             {
/* 170 */               if (Math.random() <= (SuperDuperUtil.parseTameChance(living) / 100.0F)) {
/*     */                 
/* 172 */                 SuperDuperUtil.tame(living, (LivingEntity)player);
/*     */               }
/*     */               else {
/*     */                 
/* 176 */                 for (int i = 0; i < 7; i++) {
/*     */                   
/* 178 */                   double d0 = living.f_19853_.f_46441_.m_188583_() * 0.02D;
/* 179 */                   double d1 = living.f_19853_.f_46441_.m_188583_() * 0.02D;
/* 180 */                   double d2 = living.f_19853_.f_46441_.m_188583_() * 0.02D;
/* 181 */                   living.f_19853_.m_7106_((ParticleOptions)ParticleTypes.f_123762_, living.m_20208_(1.0D), living.m_20187_() + 0.5D, living.m_20262_(1.0D), d0, d1, d2);
/*     */                 } 
/*     */               } 
/* 184 */               if (!(player.m_150110_()).f_35937_)
/*     */               {
/* 186 */                 stack.m_41774_(1);
/*     */               }
/* 188 */               event.setCancellationResult(InteractionResult.SUCCESS);
/*     */             }
/*     */           
/*     */           }
/* 192 */         } else if (player == SuperDuperUtil.getOwner(living)) {
/*     */           
/* 194 */           if (player.m_6144_()) {
/*     */             
/* 196 */             int command = SuperDuperUtil.getCommand(living) + 1;
/* 197 */             SuperDuperUtil.setCommand(living, (command >= 3) ? 0 : command);
/* 198 */             player.m_5661_((Component)Component.m_237110_("entity.superduper.all.command_" + SuperDuperUtil.getCommand(living), new Object[] { living.m_7755_() }), true);
/*     */ 
/*     */           
/*     */           }
/* 202 */           else if (player.m_21205_().m_41619_()) {
/*     */             
/* 204 */             if (!SuperDuperUtil.isRidingBlacklisted(living))
/*     */             {
/* 206 */               player.m_20329_((Entity)living);
/*     */             }
/*     */           }
/*     */           else {
/*     */             
/* 211 */             Item item = SuperDuperUtil.parseHealItem(living);
/* 212 */             if (item != null)
/*     */             {
/* 214 */               if (stack.m_150930_(item)) {
/*     */                 
/* 216 */                 float amount = SuperDuperUtil.parseHealAmount(living);
/* 217 */                 living.m_5634_(amount);
/* 218 */                 if (!(player.m_150110_()).f_35937_)
/*     */                 {
/* 220 */                   stack.m_41774_(1);
/*     */                 }
/* 222 */                 event.setCancellationResult(InteractionResult.PASS);
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public static void onLivingDeath(LivingDeathEvent event) {
/* 234 */     LivingEntity living = event.getEntity();
/* 235 */     if (SuperDuperUtil.isTame(living)) {
/*     */       
/* 237 */       LivingEntity owner = SuperDuperUtil.getOwner(living);
/* 238 */       if (!living.f_19853_.f_46443_ && living.f_19853_.m_46469_().m_46207_(GameRules.f_46142_) && owner instanceof net.minecraft.server.level.ServerPlayer)
/*     */       {
/* 240 */         owner.m_213846_(living.m_21231_().m_19293_());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public static void onLivingAttack(LivingAttackEvent event) {
/* 248 */     Entity entity = event.getSource().m_7639_();
/* 249 */     LivingEntity living = event.getEntity();
/* 250 */     if (entity != null)
/*     */     {
/* 252 */       if (entity instanceof LivingEntity) { LivingEntity attacker = (LivingEntity)entity;
/*     */         
/* 254 */         if (SuperDuperUtil.isTame(attacker)) {
/*     */           
/* 256 */           LivingEntity owner = SuperDuperUtil.getOwner(attacker);
/* 257 */           if (SuperDuperUtil.isAllay(owner, attacker, living))
/*     */           {
/* 259 */             event.setCanceled(true);
/*     */           }
/*     */         }  }
/*     */     
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superduper\event\EventHandlerForge.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */