/*    */ package com.min01.superduper.event;
/*    */ 
/*    */ import com.min01.superduper.item.SuperDuperItems;
/*    */ import net.minecraft.world.item.CreativeModeTabs;
/*    */ import net.minecraft.world.level.ItemLike;
/*    */ import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*    */ 
/*    */ 
/*    */ @EventBusSubscriber(modid = "superdupertamer", bus = Mod.EventBusSubscriber.Bus.MOD)
/*    */ public class EventHandler
/*    */ {
/*    */   @SubscribeEvent
/*    */   public static void onBuildCreativeModeTabContents(BuildCreativeModeTabContentsEvent event) {
/* 17 */     if (event.getTabKey() == CreativeModeTabs.f_256968_)
/*    */     {
/* 19 */       event.m_246326_((ItemLike)SuperDuperItems.SUPER_DUPER_ULTRA_HYPER_LEAD.get());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superduper\event\EventHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */