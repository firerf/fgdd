/*    */ package com.min01.superduper.command;
/*    */ import com.min01.superduper.util.SuperDuperUtil;
/*    */ import com.mojang.brigadier.CommandDispatcher;
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import java.util.Collection;
/*    */ import net.minecraft.commands.CommandSourceStack;
/*    */ import net.minecraft.commands.Commands;
/*    */ import net.minecraft.commands.arguments.EntityArgument;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.world.entity.Entity;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.entity.player.Player;
/*    */ 
/*    */ public class TameCommand {
/*    */   public static void register(CommandDispatcher<CommandSourceStack> p_214446_) {
/* 19 */     p_214446_.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.m_82127_("tame").requires(p_137777_ -> p_137777_.m_6761_(2)))
/*    */ 
/*    */         
/* 22 */         .then(Commands.m_82129_("pet", (ArgumentType)EntityArgument.m_91460_()).then(Commands.m_82129_("owner", (ArgumentType)EntityArgument.m_91466_()).executes(p_137810_ -> tame((CommandSourceStack)p_137810_.getSource(), EntityArgument.m_91461_(p_137810_, "pet"), (Player)EntityArgument.m_91474_(p_137810_, "owner"))))));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static int tame(CommandSourceStack stack, Collection<? extends Entity> pets, Player owner) {
/* 30 */     for (Entity pet : pets) {
/*    */       
/* 32 */       if (pet instanceof LivingEntity) { LivingEntity living = (LivingEntity)pet;
/*    */ 
/*    */         
/* 35 */         SuperDuperUtil.tame(living, (LivingEntity)owner);
/* 36 */         stack.m_288197_(() -> Component.m_237113_("Tamed " + living.m_5446_().getString() + " as owner of " + owner.m_5446_().getString()), true);
/*    */         
/*    */         continue; }
/*    */       
/* 40 */       stack.m_81352_((Component)Component.m_237113_("Unable to tame " + pet.m_5446_().getString() + ", it's not a living entity."));
/*    */     } 
/*    */     
/* 43 */     return pets.size();
/*    */   }
/*    */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superduper\command\TameCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */