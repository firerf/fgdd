/*    */ package com.min01.superduper.config;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import net.minecraftforge.common.ForgeConfigSpec;
/*    */ import org.apache.commons.lang3.tuple.Pair;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SuperDuperConfig
/*    */ {
/*    */   public static final SuperDuperConfig CONFIG;
/*    */   public static final ForgeConfigSpec CONFIG_SPEC;
/*    */   public static ForgeConfigSpec.ConfigValue<List<? extends String>> blacklist;
/*    */   public static ForgeConfigSpec.ConfigValue<List<? extends String>> tameChance;
/*    */   public static ForgeConfigSpec.BooleanValue forceTame;
/*    */   public static ForgeConfigSpec.ConfigValue<List<? extends String>> healItem;
/*    */   public static ForgeConfigSpec.ConfigValue<List<? extends String>> healAmount;
/*    */   public static ForgeConfigSpec.ConfigValue<List<? extends String>> particleWhenTamed;
/*    */   public static ForgeConfigSpec.ConfigValue<List<? extends String>> rideOffset;
/*    */   public static ForgeConfigSpec.ConfigValue<List<? extends String>> tamingItems;
/*    */   public static ForgeConfigSpec.ConfigValue<List<? extends String>> movementSpeed;
/*    */   public static ForgeConfigSpec.ConfigValue<List<? extends String>> ridingBlacklist;
/*    */   public static ForgeConfigSpec.ConfigValue<List<? extends String>> attackRange;
/*    */   public static ForgeConfigSpec.ConfigValue<List<? extends String>> teleportRange;
/*    */   
/*    */   static {
/* 31 */     Pair<SuperDuperConfig, ForgeConfigSpec> pair = (new ForgeConfigSpec.Builder()).configure(SuperDuperConfig::new);
/* 32 */     CONFIG = (SuperDuperConfig)pair.getLeft();
/* 33 */     CONFIG_SPEC = (ForgeConfigSpec)pair.getRight();
/*    */   }
/*    */ 
/*    */   
/*    */   public SuperDuperConfig(ForgeConfigSpec.Builder config) {
/* 38 */     config.push("Balance Settings");
/*    */ 
/*    */     
/* 41 */     Objects.requireNonNull(String.class); blacklist = config.comment("blacklisted mobs can't be tamed. example : minecraft:warden").defineList("blacklist", Arrays.asList(new String[] { "minecraft:warden" }, ), String.class::isInstance);
/*    */ 
/*    */     
/* 44 */     Objects.requireNonNull(String.class); tameChance = config.comment("tame success chance for mobs. example : minecraft:husk=80.0").defineList("tameChance", Arrays.asList(new String[] { "minecraft:husk=80.0" }, ), String.class::isInstance);
/* 45 */     forceTame = config.comment("enable force tame, which is able to tame any mob even if it's already tamable with other method").define("forceTame", true);
/*    */ 
/*    */     
/* 48 */     Objects.requireNonNull(String.class); healItem = config.comment("heal item for tamed mob. example : minecraft:husk=minecraft:rotten_flesh").defineList("healItem", Arrays.asList(new String[] { "minecraft:husk=minecraft:rotten_flesh" }, ), String.class::isInstance);
/*    */ 
/*    */     
/* 51 */     Objects.requireNonNull(String.class); healAmount = config.comment("heal amount for tamed mob. example : minecraft:husk=1.0").defineList("healAmount", Arrays.asList(new String[] { "minecraft:husk=1.0" }, ), String.class::isInstance);
/* 52 */     config.pop();
/*    */     
/* 54 */     config.push("Client Settings");
/*    */ 
/*    */     
/* 57 */     Objects.requireNonNull(String.class); particleWhenTamed = config.comment("particle for when successfully tamed mobs. example : minecraft:husk=minecraft:damage_indicator").defineList("particleWhenTamed", Arrays.asList(new String[] { "minecraft:husk=minecraft:damage_indicator" }, ), String.class::isInstance);
/* 58 */     Objects.requireNonNull(String.class); rideOffset = config.comment("y offset of passenger when ride tamed mob. example : minecraft:husk=0.5").defineList("mountOffset", Arrays.asList(new String[0]), String.class::isInstance);
/* 59 */     config.pop();
/*    */     
/* 61 */     config.push("Common Settings");
/*    */ 
/*    */     
/* 64 */     Objects.requireNonNull(String.class); tamingItems = config.comment("item needed for tame mobs. example : minecraft:husk=minecraft:rotten_flesh").defineList("tamingItems", Arrays.asList(new String[] { "minecraft:husk=minecraft:rotten_flesh" }, ), String.class::isInstance);
/*    */ 
/*    */     
/* 67 */     Objects.requireNonNull(String.class); movementSpeed = config.comment("movementSpeed for when pets following owner or controlled by owner. example : minecraft:husk=1.3").defineList("movementSpeed", Arrays.asList(new String[] { "minecraft:husk=1.3" }, ), String.class::isInstance);
/* 68 */     Objects.requireNonNull(String.class); ridingBlacklist = config.comment("disable riding of specific mob. example : minecraft:husk").defineList("ridingBlacklist", Arrays.asList(new String[0]), String.class::isInstance);
/* 69 */     Objects.requireNonNull(String.class); attackRange = config.comment("minimum range for tamed mob attack target while in following state. example : minecraft:husk=3.5").defineList("attackRange", Arrays.asList(new String[0]), String.class::isInstance);
/* 70 */     Objects.requireNonNull(String.class); teleportRange = config.comment("minimum range for tamed mob teleport to owner. example : minecraft:husk=10.0").defineList("teleportRange", Arrays.asList(new String[0]), String.class::isInstance);
/* 71 */     config.pop();
/*    */   }
/*    */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superduper\config\SuperDuperConfig.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */