/*   */ package com.min01.superduper.util;
/*   */ 
/*   */ import net.minecraft.client.Minecraft;
/*   */ 
/*   */ public class SuperDuperClientUtil
/*   */ {
/* 7 */   public static final Minecraft MC = Minecraft.m_91087_();
/*   */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superdupe\\util\SuperDuperClientUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */