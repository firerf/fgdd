/*     */ package com.min01.superduper.util;
/*     */ 
/*     */ import com.min01.superduper.ai.goal.SuperDuperFollowOwnerGoal;
/*     */ import com.min01.superduper.ai.goal.SuperDuperOwnerHurtByTargetGoal;
/*     */ import com.min01.superduper.ai.goal.SuperDuperOwnerHurtTargetGoal;
/*     */ import com.min01.superduper.config.SuperDuperConfig;
/*     */ import com.mojang.brigadier.StringReader;
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.core.particles.ParticleOptions;
/*     */ import net.minecraft.core.particles.ParticleType;
/*     */ import net.minecraft.core.particles.ParticleTypes;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.Mob;
/*     */ import net.minecraft.world.entity.TamableAnimal;
/*     */ import net.minecraft.world.entity.ai.goal.Goal;
/*     */ import net.minecraft.world.item.Item;
/*     */ import net.minecraft.world.level.Level;
/*     */ import net.minecraft.world.level.entity.LevelEntityGetter;
/*     */ import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
/*     */ import net.minecraftforge.registries.ForgeRegistries;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SuperDuperUtil
/*     */ {
/*     */   public static void tame(LivingEntity pet, LivingEntity owner) {
/*  32 */     if (!isTame(owner)) {
/*     */       
/*  34 */       setOwner(pet, owner);
/*  35 */       for (int i = 0; i < 7; i++) {
/*     */         
/*  37 */         double d0 = pet.f_19853_.f_46441_.m_188583_() * 0.02D;
/*  38 */         double d1 = pet.f_19853_.f_46441_.m_188583_() * 0.02D;
/*  39 */         double d2 = pet.f_19853_.f_46441_.m_188583_() * 0.02D;
/*  40 */         pet.f_19853_.m_7106_(parseParticleForTaming(pet), pet.m_20208_(1.0D), pet.m_20187_() + 0.5D, pet.m_20262_(1.0D), d0, d1, d2);
/*     */       } 
/*  42 */       if (pet instanceof Mob) { Mob mob = (Mob)pet;
/*     */         
/*  44 */         mob.m_21530_();
/*  45 */         mob.m_6710_(null);
/*  46 */         mob.f_21345_.m_25352_(2, (Goal)new SuperDuperFollowOwnerGoal(mob, parseMovementSpeed((LivingEntity)mob), 4.0F, 2.0F, true));
/*  47 */         mob.f_21346_.m_25352_(1, (Goal)new SuperDuperOwnerHurtByTargetGoal(mob));
/*  48 */         mob.f_21346_.m_25352_(2, (Goal)new SuperDuperOwnerHurtTargetGoal(mob)); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static double parseRideOffset(LivingEntity entity) {
/*  55 */     ResourceLocation location = ForgeRegistries.ENTITY_TYPES.getKey(entity.m_6095_());
/*  56 */     List<? extends String> list = (List<? extends String>)SuperDuperConfig.rideOffset.get();
/*  57 */     for (String string : list) {
/*     */       
/*  59 */       String mobId = string.split("=")[0];
/*  60 */       String y = string.split("=")[1];
/*  61 */       if (location.toString().equals(mobId))
/*     */       {
/*  63 */         return Float.valueOf(y).floatValue();
/*     */       }
/*     */     } 
/*  66 */     return entity.m_20206_() * 0.75D;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Item parseHealItem(LivingEntity entity) {
/*  71 */     ResourceLocation location = ForgeRegistries.ENTITY_TYPES.getKey(entity.m_6095_());
/*  72 */     List<? extends String> list = (List<? extends String>)SuperDuperConfig.healItem.get();
/*  73 */     for (String string : list) {
/*     */       
/*  75 */       String mobId = string.split("=")[0];
/*  76 */       String itemId = string.split("=")[1];
/*  77 */       if (location.toString().equals(mobId))
/*     */       {
/*  79 */         return (Item)ForgeRegistries.ITEMS.getValue(new ResourceLocation(itemId));
/*     */       }
/*     */     } 
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static float parseHealAmount(LivingEntity entity) {
/*  87 */     ResourceLocation location = ForgeRegistries.ENTITY_TYPES.getKey(entity.m_6095_());
/*  88 */     List<? extends String> list = (List<? extends String>)SuperDuperConfig.healAmount.get();
/*  89 */     for (String string : list) {
/*     */       
/*  91 */       String mobId = string.split("=")[0];
/*  92 */       String amount = string.split("=")[1];
/*  93 */       if (location.toString().equals(mobId))
/*     */       {
/*  95 */         return Float.valueOf(amount).floatValue();
/*     */       }
/*     */     } 
/*  98 */     return 1.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public static float parseTameChance(LivingEntity entity) {
/* 103 */     ResourceLocation location = ForgeRegistries.ENTITY_TYPES.getKey(entity.m_6095_());
/* 104 */     List<? extends String> list = (List<? extends String>)SuperDuperConfig.tameChance.get();
/* 105 */     for (String string : list) {
/*     */       
/* 107 */       String mobId = string.split("=")[0];
/* 108 */       String chance = string.split("=")[1];
/* 109 */       if (location.toString().equals(mobId))
/*     */       {
/* 111 */         return Float.valueOf(chance).floatValue();
/*     */       }
/*     */     } 
/* 114 */     return 100.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isRidingBlacklisted(LivingEntity entity) {
/* 119 */     ResourceLocation location = ForgeRegistries.ENTITY_TYPES.getKey(entity.m_6095_());
/* 120 */     List<? extends String> list = (List<? extends String>)SuperDuperConfig.ridingBlacklist.get();
/* 121 */     if (!list.isEmpty())
/*     */     {
/* 123 */       return list.contains(location.toString());
/*     */     }
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isBlacklisted(LivingEntity entity) {
/* 130 */     ResourceLocation location = ForgeRegistries.ENTITY_TYPES.getKey(entity.m_6095_());
/* 131 */     List<? extends String> list = (List<? extends String>)SuperDuperConfig.blacklist.get();
/* 132 */     if (!list.isEmpty())
/*     */     {
/* 134 */       return list.contains(location.toString());
/*     */     }
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isInAttackRange(LivingEntity entity, Entity target) {
/* 141 */     return (entity.m_20270_(target) <= parseAttackRange(entity));
/*     */   }
/*     */ 
/*     */   
/*     */   public static float parseTeleportRange(LivingEntity entity) {
/* 146 */     ResourceLocation location = ForgeRegistries.ENTITY_TYPES.getKey(entity.m_6095_());
/* 147 */     List<? extends String> list = (List<? extends String>)SuperDuperConfig.teleportRange.get();
/* 148 */     for (String string : list) {
/*     */       
/* 150 */       String mobId = string.split("=")[0];
/* 151 */       String range = string.split("=")[1];
/* 152 */       if (location.toString().equals(mobId))
/*     */       {
/* 154 */         return Float.valueOf(range).floatValue();
/*     */       }
/*     */     } 
/* 157 */     return 144.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public static float parseAttackRange(LivingEntity entity) {
/* 162 */     ResourceLocation location = ForgeRegistries.ENTITY_TYPES.getKey(entity.m_6095_());
/* 163 */     List<? extends String> list = (List<? extends String>)SuperDuperConfig.attackRange.get();
/* 164 */     for (String string : list) {
/*     */       
/* 166 */       String mobId = string.split("=")[0];
/* 167 */       String range = string.split("=")[1];
/* 168 */       if (location.toString().equals(mobId))
/*     */       {
/* 170 */         return Float.valueOf(range).floatValue();
/*     */       }
/*     */     } 
/* 173 */     return 1000.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public static float parseMovementSpeed(LivingEntity entity) {
/* 178 */     ResourceLocation location = ForgeRegistries.ENTITY_TYPES.getKey(entity.m_6095_());
/* 179 */     List<? extends String> list = (List<? extends String>)SuperDuperConfig.movementSpeed.get();
/* 180 */     for (String string : list) {
/*     */       
/* 182 */       String mobId = string.split("=")[0];
/* 183 */       String speed = string.split("=")[1];
/* 184 */       if (location.toString().equals(mobId))
/*     */       {
/* 186 */         return Float.valueOf(speed).floatValue();
/*     */       }
/*     */     } 
/* 189 */     return 1.3F;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends ParticleOptions> ParticleOptions parseParticleForTaming(LivingEntity entity) {
/* 195 */     ResourceLocation location = ForgeRegistries.ENTITY_TYPES.getKey(entity.m_6095_());
/* 196 */     List<? extends String> list = (List<? extends String>)SuperDuperConfig.particleWhenTamed.get();
/* 197 */     for (String string : list) {
/*     */       
/* 199 */       String mobId = string.split("=")[0];
/* 200 */       String particleId = string.split("=")[1];
/* 201 */       if (location.toString().equals(mobId)) {
/*     */         
/* 203 */         ParticleType<T> particleType = (ParticleType<T>)ForgeRegistries.PARTICLE_TYPES.getValue(new ResourceLocation(particleId));
/*     */         
/*     */         try {
/* 206 */           StringReader reader = new StringReader(particleId);
/* 207 */           return particleType.m_123743_().m_5739_(particleType, reader);
/*     */         }
/* 209 */         catch (CommandSyntaxException e) {
/*     */           
/* 211 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/*     */     } 
/* 215 */     return (ParticleOptions)ParticleTypes.f_123750_;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Item parseItemForTaming(LivingEntity entity) {
/* 220 */     ResourceLocation location = ForgeRegistries.ENTITY_TYPES.getKey(entity.m_6095_());
/* 221 */     List<? extends String> list = (List<? extends String>)SuperDuperConfig.tamingItems.get();
/* 222 */     for (String string : list) {
/*     */       
/* 224 */       String mobId = string.split("=")[0];
/* 225 */       String itemId = string.split("=")[1];
/* 226 */       if (location.toString().equals(mobId))
/*     */       {
/* 228 */         return (Item)ForgeRegistries.ITEMS.getValue(new ResourceLocation(itemId));
/*     */       }
/*     */     } 
/* 231 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isAllay(LivingEntity owner, LivingEntity mob, LivingEntity target) {
/* 236 */     if (owner != target && !isSameOwner(mob, target)) { if (target instanceof TamableAnimal) { TamableAnimal animal = (TamableAnimal)target; if (animal.m_21830_(owner)); }  return false; }
/*     */   
/*     */   }
/*     */   
/*     */   public static boolean isSameOwner(LivingEntity entity, LivingEntity target) {
/* 241 */     if (isTame(target)) { if (getOwner(target) != getOwner(entity)) if (entity instanceof TamableAnimal) { TamableAnimal animal = (TamableAnimal)entity; if (animal.m_269323_() != null && animal.m_269323_() == getOwner(target)); }   } else { return false; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWandering(LivingEntity entity) {
/* 250 */     return (isTame(entity) && getCommand(entity) == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isFollow(LivingEntity entity) {
/* 255 */     return (isTame(entity) && getCommand(entity) == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSit(LivingEntity entity) {
/* 260 */     return (isTame(entity) && getCommand(entity) == 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isTame(LivingEntity entity) {
/* 265 */     return (getOwner(entity) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setCommand(LivingEntity entity, int command) {
/* 270 */     entity.getPersistentData().m_128405_("Command", command);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getCommand(LivingEntity entity) {
/* 275 */     return entity.getPersistentData().m_128451_("Command");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setLastHurtByMob(LivingEntity entity, LivingEntity mob) {
/* 280 */     entity.getPersistentData().m_128362_("LastHurtByMobUUID", mob.m_20148_());
/*     */   }
/*     */ 
/*     */   
/*     */   public static LivingEntity getLastHurtByMob(LivingEntity entity) {
/* 285 */     if (entity.getPersistentData().m_128441_("LastHurtByMobUUID")) {
/*     */       
/* 287 */       Entity lastHurtByMob = getEntityByUUID(entity.f_19853_, entity.getPersistentData().m_128342_("LastHurtByMobUUID"));
/* 288 */       if (lastHurtByMob instanceof LivingEntity) { LivingEntity living = (LivingEntity)lastHurtByMob;
/*     */         
/* 290 */         return living; }
/*     */     
/*     */     } 
/* 293 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setLastHurtMob(LivingEntity entity, LivingEntity mob) {
/* 298 */     entity.getPersistentData().m_128362_("LastHurtMobUUID", mob.m_20148_());
/*     */   }
/*     */ 
/*     */   
/*     */   public static LivingEntity getLastHurtMob(LivingEntity entity) {
/* 303 */     if (entity.getPersistentData().m_128441_("LastHurtMobUUID")) {
/*     */       
/* 305 */       Entity lastHurtMob = getEntityByUUID(entity.f_19853_, entity.getPersistentData().m_128342_("LastHurtMobUUID"));
/* 306 */       if (lastHurtMob instanceof LivingEntity) { LivingEntity living = (LivingEntity)lastHurtMob;
/*     */         
/* 308 */         return living; }
/*     */     
/*     */     } 
/* 311 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setOwner(LivingEntity entity, LivingEntity owner) {
/* 316 */     entity.getPersistentData().m_128362_("OwnerUUID", owner.m_20148_());
/*     */   }
/*     */ 
/*     */   
/*     */   public static LivingEntity getOwner(LivingEntity entity) {
/* 321 */     if (entity.getPersistentData().m_128441_("OwnerUUID")) {
/*     */       
/* 323 */       Entity owner = getEntityByUUID(entity.f_19853_, entity.getPersistentData().m_128342_("OwnerUUID"));
/* 324 */       if (owner instanceof LivingEntity) { LivingEntity living = (LivingEntity)owner;
/*     */         
/* 326 */         return living; }
/*     */     
/*     */     } 
/* 329 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Entity getEntityByUUID(Level level, UUID uuid) {
/* 335 */     Method m = ObfuscationReflectionHelper.findMethod(Level.class, "m_142646_", new Class[0]);
/*     */     
/*     */     try {
/* 338 */       LevelEntityGetter<Entity> entities = (LevelEntityGetter<Entity>)m.invoke(level, new Object[0]);
/* 339 */       return (Entity)entities.m_142694_(uuid);
/*     */     }
/* 341 */     catch (Exception e) {
/*     */       
/* 343 */       e.printStackTrace();
/*     */       
/* 345 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superdupe\\util\SuperDuperUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */