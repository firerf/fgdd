/*    */ package com.min01.superduper.ai.goal;
/*    */ 
/*    */ import com.min01.superduper.util.SuperDuperUtil;
/*    */ import java.util.EnumSet;
/*    */ import net.minecraft.world.entity.LivingEntity;
/*    */ import net.minecraft.world.entity.Mob;
/*    */ import net.minecraft.world.entity.ai.goal.Goal;
/*    */ import net.minecraft.world.entity.ai.goal.target.TargetGoal;
/*    */ import net.minecraft.world.entity.ai.targeting.TargetingConditions;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SuperDuperOwnerHurtTargetGoal
/*    */   extends TargetGoal
/*    */ {
/*    */   private final Mob mob;
/*    */   private LivingEntity ownerLastHurt;
/*    */   private int timestamp;
/*    */   
/*    */   public SuperDuperOwnerHurtTargetGoal(Mob mob) {
/* 21 */     super(mob, false);
/* 22 */     this.mob = mob;
/* 23 */     m_7021_(EnumSet.of(Goal.Flag.TARGET));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean m_8036_() {
/* 29 */     if (SuperDuperUtil.isTame((LivingEntity)this.mob) && !SuperDuperUtil.isSit((LivingEntity)this.mob)) {
/*    */       
/* 31 */       LivingEntity livingentity = SuperDuperUtil.getOwner((LivingEntity)this.mob);
/* 32 */       if (livingentity == null)
/*    */       {
/* 34 */         return false;
/*    */       }
/*    */ 
/*    */       
/* 38 */       this.ownerLastHurt = livingentity.m_21214_();
/* 39 */       int i = livingentity.m_21215_();
/* 40 */       return (i != this.timestamp && m_26150_(this.ownerLastHurt, TargetingConditions.m_148353_()));
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 45 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void m_8056_() {
/* 52 */     this.mob.m_6710_(this.ownerLastHurt);
/* 53 */     LivingEntity livingentity = SuperDuperUtil.getOwner((LivingEntity)this.mob);
/* 54 */     if (livingentity != null)
/*    */     {
/* 56 */       this.timestamp = livingentity.m_21215_();
/*    */     }
/* 58 */     super.m_8056_();
/*    */   }
/*    */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superduper\ai\goal\SuperDuperOwnerHurtTargetGoal.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */