/*     */ package com.min01.superduper.ai.goal;
/*     */ 
/*     */ import com.min01.superduper.util.SuperDuperUtil;
/*     */ import java.util.EnumSet;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.core.Vec3i;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.LivingEntity;
/*     */ import net.minecraft.world.entity.Mob;
/*     */ import net.minecraft.world.entity.ai.goal.Goal;
/*     */ import net.minecraft.world.entity.ai.navigation.PathNavigation;
/*     */ import net.minecraft.world.level.BlockGetter;
/*     */ import net.minecraft.world.level.LevelReader;
/*     */ import net.minecraft.world.level.block.state.BlockState;
/*     */ import net.minecraft.world.level.pathfinder.BlockPathTypes;
/*     */ import net.minecraft.world.level.pathfinder.WalkNodeEvaluator;
/*     */ 
/*     */ public class SuperDuperFollowOwnerGoal
/*     */   extends Goal
/*     */ {
/*     */   public static final int TELEPORT_WHEN_DISTANCE_IS = 12;
/*     */   private final Mob mob;
/*     */   private LivingEntity owner;
/*     */   private final LevelReader level;
/*     */   private final double speedModifier;
/*     */   private final PathNavigation navigation;
/*     */   private int timeToRecalcPath;
/*     */   private final float stopDistance;
/*     */   private final float startDistance;
/*     */   private float oldWaterCost;
/*     */   private final boolean canFly;
/*     */   
/*     */   public SuperDuperFollowOwnerGoal(Mob mob, double speedModifier, float startDistance, float stopDistance, boolean canFly) {
/*  34 */     this.mob = mob;
/*  35 */     this.level = (LevelReader)mob.f_19853_;
/*  36 */     this.speedModifier = speedModifier;
/*  37 */     this.navigation = mob.m_21573_();
/*  38 */     this.startDistance = startDistance;
/*  39 */     this.stopDistance = stopDistance;
/*  40 */     this.canFly = canFly;
/*  41 */     m_7021_(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean m_8036_() {
/*  47 */     LivingEntity livingentity = SuperDuperUtil.getOwner((LivingEntity)this.mob);
/*  48 */     if (livingentity == null)
/*     */     {
/*  50 */       return false;
/*     */     }
/*  52 */     if (livingentity.m_5833_())
/*     */     {
/*  54 */       return false;
/*     */     }
/*  56 */     if (SuperDuperUtil.isSit((LivingEntity)this.mob))
/*     */     {
/*  58 */       return false;
/*     */     }
/*  60 */     if (this.mob.m_5448_() != null)
/*     */     {
/*  62 */       return false;
/*     */     }
/*  64 */     if (this.mob.m_20280_((Entity)livingentity) < (this.startDistance * this.startDistance))
/*     */     {
/*  66 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  70 */     this.owner = livingentity;
/*  71 */     return SuperDuperUtil.isFollow((LivingEntity)this.mob);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean m_8045_() {
/*  78 */     if (this.navigation.m_26571_())
/*     */     {
/*  80 */       return false;
/*     */     }
/*  82 */     if (SuperDuperUtil.isSit((LivingEntity)this.mob))
/*     */     {
/*  84 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  88 */     return (this.mob.m_20280_((Entity)this.owner) > (this.stopDistance * this.stopDistance));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_8056_() {
/*  95 */     this.timeToRecalcPath = 0;
/*  96 */     this.oldWaterCost = this.mob.m_21439_(BlockPathTypes.WATER);
/*  97 */     this.mob.m_21441_(BlockPathTypes.WATER, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_8041_() {
/* 103 */     this.owner = null;
/* 104 */     this.navigation.m_26573_();
/* 105 */     this.mob.m_21441_(BlockPathTypes.WATER, this.oldWaterCost);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void m_8037_() {
/* 111 */     this.mob.m_21563_().m_24960_((Entity)this.owner, 10.0F, this.mob.m_8132_());
/* 112 */     if (--this.timeToRecalcPath <= 0) {
/*     */       
/* 114 */       this.timeToRecalcPath = m_183277_(10);
/* 115 */       if (!this.mob.m_21523_() && !this.mob.m_20159_())
/*     */       {
/* 117 */         if (this.mob.m_20280_((Entity)this.owner) >= SuperDuperUtil.parseTeleportRange((LivingEntity)this.mob)) {
/*     */           
/* 119 */           teleportToOwner();
/*     */         }
/*     */         else {
/*     */           
/* 123 */           this.navigation.m_5624_((Entity)this.owner, this.speedModifier);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void teleportToOwner() {
/* 131 */     BlockPos blockpos = this.owner.m_20183_();
/* 132 */     for (int i = 0; i < 10; i++) {
/*     */       
/* 134 */       int j = randomIntInclusive(-3, 3);
/* 135 */       int k = randomIntInclusive(-1, 1);
/* 136 */       int l = randomIntInclusive(-3, 3);
/* 137 */       boolean flag = maybeTeleportTo(blockpos.m_123341_() + j, blockpos.m_123342_() + k, blockpos.m_123343_() + l);
/* 138 */       if (flag) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean maybeTeleportTo(int p_25304_, int p_25305_, int p_25306_) {
/* 147 */     if (Math.abs(p_25304_ - this.owner.m_20185_()) < 2.0D && Math.abs(p_25306_ - this.owner.m_20189_()) < 2.0D)
/*     */     {
/* 149 */       return false;
/*     */     }
/* 151 */     if (!canTeleportTo(new BlockPos(p_25304_, p_25305_, p_25306_)))
/*     */     {
/* 153 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 157 */     this.mob.m_7678_(p_25304_ + 0.5D, p_25305_, p_25306_ + 0.5D, this.mob.m_146908_(), this.mob.m_146909_());
/* 158 */     this.navigation.m_26573_();
/* 159 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean canTeleportTo(BlockPos p_25308_) {
/* 165 */     BlockPathTypes blockpathtypes = WalkNodeEvaluator.m_77604_((BlockGetter)this.level, p_25308_.m_122032_());
/* 166 */     if (blockpathtypes != BlockPathTypes.WALKABLE)
/*     */     {
/* 168 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 172 */     BlockState blockstate = this.level.m_8055_(p_25308_.m_7495_());
/* 173 */     if (!this.canFly && blockstate.m_60734_() instanceof net.minecraft.world.level.block.LeavesBlock)
/*     */     {
/* 175 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 179 */     BlockPos blockpos = p_25308_.m_121996_((Vec3i)this.mob.m_20183_());
/* 180 */     return this.level.m_45756_((Entity)this.mob, this.mob.m_20191_().m_82338_(blockpos));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int randomIntInclusive(int p_25301_, int p_25302_) {
/* 187 */     return this.mob.m_217043_().m_188503_(p_25302_ - p_25301_ + 1) + p_25301_;
/*     */   }
/*     */ }


/* Location:              C:\Users\chris\Downloads\superdupertamer-1.0.0.jar!\com\min01\superduper\ai\goal\SuperDuperFollowOwnerGoal.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */